<template>
  <div>/views/tmp2.vue</div>
</template>

<script>
export default {
  name: "tmp2",
};
</script>

<style></style>
