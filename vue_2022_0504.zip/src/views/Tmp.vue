<template>
  <div>/views/tmp.vue</div>
</template>

<script>
export default {
  name: "tmp",
};
</script>

<style></style>
